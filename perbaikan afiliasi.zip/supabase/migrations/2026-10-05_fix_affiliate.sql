-- Perbaikan kode referral kosong untuk user lama / Google / profil telat dibuat.
-- Jalankan di Supabase -> SQL Editor (setelah 2026-09-30_referral_commission.sql).

-- 1) Trigger: user boleh MENGISI kode bila masih kosong; mengubah kode yang sudah ada tetap ditolak.
create or replace function public.profiles_guard_referral_code()
returns trigger language plpgsql as $$
begin
  if tg_op = 'INSERT' then
    new.referral_code := public.gen_referral_code();
  elsif old.referral_code is not null
        and new.referral_code is distinct from old.referral_code
        and not public.is_admin() then
    new.referral_code := old.referral_code;
  end if;
  return new;
end $$;

-- 2) Fungsi server: buat profil bila belum ada, isi kode bila kosong, kembalikan kodenya.
create or replace function public.ensure_my_referral_code()
returns text language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_code text;
begin
  if v_uid is null then return null; end if;

  insert into public.profiles (id, email)
  select u.id, u.email from auth.users u where u.id = v_uid
  on conflict (id) do nothing;

  select referral_code into v_code from public.profiles where id = v_uid;
  if v_code is null then
    update public.profiles set referral_code = public.gen_referral_code()
    where id = v_uid and referral_code is null
    returning referral_code into v_code;
  end if;
  return v_code;
end $$;

revoke all on function public.ensure_my_referral_code() from public;
grant execute on function public.ensure_my_referral_code() to authenticated;

-- 3) Isi kode untuk semua user lama yang masih kosong
update public.profiles set referral_code = public.gen_referral_code() where referral_code is null;
