import { useEffect, useState } from 'react';
import { supabase, isSupabaseConfigured } from './supabase';

// Tarif sebenarnya diatur admin (tabel app_settings) dan dibaca lewat useCommissionRate().
// Konstanta ini hanya cadangan tampilan; server yang menentukan nilai komisi.
export { DEFAULT_COMMISSION_RATE as COMMISSION_RATE } from './commissionRate';
import { DEFAULT_COMMISSION_RATE } from './commissionRate';

const KEY = 'bu_ref_v1';
const TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 hari

export type CommissionType = 'default' | 'percent' | 'fixed';

/** Aturan komisi sebuah produk (dari kolom commission_type / commission_value). */
export interface CommissionConfig {
  commissionType?: CommissionType;
  commissionValue?: number;
}

/**
 * Estimasi komisi untuk satu produk. Rumus sama dengan fungsi calc_commission di SQL
 * (server yang menentukan nilai sebenarnya):
 *  - fixed   : nominal tetap, maksimal sebesar harga paket
 *  - percent : harga jual x persen produk
 *  - default : harga jual x tarif umum (diatur admin)
 */
export function commissionFor(
  sellingPrice: number,
  cfg?: CommissionConfig,
  defaultRate: number = DEFAULT_COMMISSION_RATE
): number {
  const value = Number(cfg?.commissionValue) || 0;
  if (cfg?.commissionType === 'fixed') return Math.min(Math.floor(value), Math.floor(sellingPrice));
  if (cfg?.commissionType === 'percent') return Math.floor((sellingPrice * value) / 100);
  return Math.floor(sellingPrice * defaultRate);
}

/** Teks singkat aturan komisi: "25%" atau "Rp 200.000". */
export function commissionPhrase(cfg: CommissionConfig | undefined, defaultRate: number): string {
  const value = Number(cfg?.commissionValue) || 0;
  if (cfg?.commissionType === 'fixed') return formatRupiah(value);
  if (cfg?.commissionType === 'percent') return `${Number(value.toFixed(2))}%`;
  return `${Number((defaultRate * 100).toFixed(1))}%`;
}

export function formatRupiah(n: number): string {
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

/**
 * Panggil sekali saat aplikasi dibuka. Menyimpan ?ref= ke localStorage (30 hari),
 * lalu mengembalikan ?produk= (kalau ada) supaya modal order bisa langsung dibuka.
 * Parameter dibersihkan dari URL.
 */
export function captureReferralFromUrl(): { productKey: string | null } {
  let productKey: string | null = null;
  try {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    const pathMatch = window.location.pathname.match(/^\/paket\/([^/]+)\/?$/);
    productKey = pathMatch ? decodeURIComponent(pathMatch[1]) : params.get('produk');

    if (ref && /^[A-Za-z0-9]{4,16}$/.test(ref)) {
      localStorage.setItem(KEY, JSON.stringify({ code: ref.toUpperCase(), exp: Date.now() + TTL_MS }));
    }
    if (ref || productKey) {
      const onPaketPath = Boolean(pathMatch);
      params.delete('ref');
      params.delete('produk');
      const qs = params.toString();
      const cleanPath = onPaketPath ? '/' : window.location.pathname;
      window.history.replaceState({}, '', cleanPath + (qs ? `?${qs}` : '') + window.location.hash);
    }
  } catch { /* localStorage bisa diblokir: abaikan */ }
  return { productKey };
}

export function getStoredReferralCode(): string | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const { code, exp } = JSON.parse(raw) as { code: string; exp: number };
    if (!code || Date.now() > exp) {
      localStorage.removeItem(KEY);
      return null;
    }
    return code;
  } catch {
    return null;
  }
}

export function buildProductShareUrl(productKey: string, code: string): string {
  return `${window.location.origin}/paket/${encodeURIComponent(productKey)}?ref=${encodeURIComponent(code)}`;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * Ambil kode referral user. Kalau profil/kode belum ada (user lama, signup lewat
 * Google, trigger terlambat), minta server membuatnya lewat RPC ensure_my_referral_code.
 */
async function loadOrCreateReferralCode(uid: string): Promise<string | null> {
  if (!supabase) return null;
  for (let attempt = 0; attempt < 3; attempt++) {
    const { data } = await supabase
      .from('profiles')
      .select('referral_code')
      .eq('id', uid)
      .maybeSingle();
    if (data?.referral_code) return data.referral_code as string;

    const { data: created, error } = await supabase.rpc('ensure_my_referral_code');
    if (!error && typeof created === 'string' && created) return created;
    if (error) console.warn('[referral] ensure_my_referral_code:', error.message);

    await sleep(500 * (attempt + 1));
  }
  return null;
}

export interface ReferralState {
  /** Kode referral user (null = belum siap / belum login). */
  code: string | null;
  /** true selama kode sedang dimuat. */
  loading: boolean;
  /** Coba muat ulang kode (dipakai tombol "Muat ulang"). */
  retry: () => void;
}

/** Kode referral milik user yang sedang login, dengan status memuat & coba lagi. */
export function useReferral(uid: string | null): ReferralState {
  const [code, setCode] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let alive = true;
    if (!uid || !isSupabaseConfigured || !supabase) {
      setCode(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    loadOrCreateReferralCode(uid)
      .then((c) => { if (alive) setCode(c); })
      .catch((e) => console.error('[useReferral]', e))
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [uid, tick]);

  return { code, loading, retry: () => setTick((t) => t + 1) };
}

/** Kompatibilitas lama: hanya mengembalikan kodenya. */
export function useReferralCode(uid: string | null): string | null {
  return useReferral(uid).code;
}

export interface ReferralStats {
  referredOrders: number;
  paidOrders: number;
}

export async function fetchMyReferralStats(): Promise<ReferralStats | null> {
  if (!isSupabaseConfigured || !supabase) return null;
  const { data, error } = await supabase.rpc('my_referral_stats');
  if (error) {
    console.warn('[fetchMyReferralStats]', error.message);
    return null;
  }
  const row = (Array.isArray(data) ? data[0] : data) as { referred_orders?: number; paid_orders?: number } | null;
  return {
    referredOrders: Number(row?.referred_orders || 0),
    paidOrders: Number(row?.paid_orders || 0),
  };
}

/** Ringkasan pendapatan afiliasi dari daftar komisi. Komisi 'cancelled' tidak dihitung. */
export function summarizeCommissions(rows: { amount: number; status: string }[]) {
  const sum = (s: string) => rows.filter((r) => r.status === s).reduce((a, r) => a + Number(r.amount), 0);
  const pending = sum('pending');
  const approved = sum('approved');
  const paid = sum('paid');
  return { pending, approved, paid, total: pending + approved + paid };
}

export interface CommissionRow {
  id: string;
  order_id: string;
  base_amount: number;
  rate: number;
  amount: number;
  status: 'pending' | 'approved' | 'paid' | 'cancelled';
  created_at: string;
  /** 'fixed' = nominal tetap per produk; selain itu = persentase. */
  commission_type?: 'percent' | 'fixed' | null;
}

export async function fetchMyCommissions(): Promise<CommissionRow[]> {
  if (!isSupabaseConfigured || !supabase) return [];
  // Admin bisa membaca semua komisi lewat RLS; di dashboard tampilkan hanya milik sendiri.
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return [];
  const cols = 'id, order_id, base_amount, rate, amount, status, created_at';
  let res: { data: unknown; error: { message: string } | null } = await supabase
    .from('commissions')
    .select(`${cols}, commission_type`)
    .eq('referrer_id', uid)
    .order('created_at', { ascending: false });
  // kolom commission_type baru ada setelah migrasi komisi-per-produk dijalankan
  if (res.error && /commission_type/i.test(res.error.message)) {
    res = await supabase.from('commissions').select(cols).eq('referrer_id', uid).order('created_at', { ascending: false });
  }
  if (res.error) {
    console.error('[fetchMyCommissions]', res.error);
    return [];
  }
  return (res.data || []) as CommissionRow[];
}
